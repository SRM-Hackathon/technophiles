package paper ;/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "insertpp", urlPatterns = {"/insertpp"})
public class insertpp extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try  {   
            int ibo = 0;
            int icha = 0;
            int ico = 0;            int ibag = 0;            
                 int   ibottle =0;
                 int   ichair =0;
                 int   icontainers=0;
                 int   ibags=0;
                 
                 int ib =0;
           int iba = 0;
           int ic = 0;
           int ich = 0;
           Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/salecategory","root","");
                      Statement st = con.createStatement();

                       ResultSet rs=st.executeQuery("select * from paper");
rs.next();
            String a=rs.getString("PNews");
            String b=rs.getString("PBoards");
            String c=rs.getString("PBooks");
            String d=rs.getString("PBags");
            
            ib = Integer.parseInt(a);
            iba = Integer.parseInt(b);
            ic = Integer.parseInt(c);
            ich = Integer.parseInt(d);

            String bottles = request.getParameter("txtnews");
            String chairs = request.getParameter("txtpboards");
            String containers = request.getParameter("txtbooks");
            String bags = request.getParameter("txtpbags");
            
             ibo = Integer.parseInt(bottles);
             icha = Integer.parseInt(chairs);
             ico = Integer.parseInt(containers);
             ibag = Integer.parseInt(bags);
            
                    ibottle = ib+ibo;
                    ichair = iba+icha;
                    icontainers=ic+ico;
                    ibags=ich+ibag;
                    Statement s=con.createStatement();
            s.execute("insert into paper(PNews,PBoards,PBooks,PBags)values('"+ibottle+"','"+ichair+"','"+icontainers+"','"+ibags+"')");
            out.print("Data inserted Successfully..!!");
            
        }
        catch(Exception e)
        {
            out.print(e);
        }
        finally {            
            out.close();
        }
    }

    }

