/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package plastic;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author scom
 */
public class plasticr extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
          response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
                       
            int ibo = 0;
            int icha = 0;
            int ico = 0;            int ibag = 0;            
                 int   ibottle =0;
                 int   ichair =0;
                 int   icontainers=0;
                 int   ibags=0;
                 
                 int ib =0;
           int iba = 0;
           int ic = 0;
           int ich = 0;
 
              Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/salecategory","root","");
                      Statement st = con.createStatement();

                       ResultSet rs=st.executeQuery("select * from plastic");
rs.next();
            String a=rs.getString("PBottles");
            String b=rs.getString("PBags");
            String c=rs.getString("PContainers");
            String d=rs.getString("PChairs");
            
            ib = Integer.parseInt(a);
            iba = Integer.parseInt(b);
            ic = Integer.parseInt(c);
            ich = Integer.parseInt(d);

            String bottles = request.getParameter("txtbottle");
            String chairs = request.getParameter("txtchair");
            String containers = request.getParameter("txtcontainer");
            String bags = request.getParameter("txtbags");
            
             ibo = Integer.parseInt(bottles);
             icha = Integer.parseInt(chairs);
             ico = Integer.parseInt(containers);
             ibag = Integer.parseInt(bags);
            
                    ibottle = ib+ibo;
                    ichair = ich+icha;
                    icontainers=ic+ico;
                    ibags=iba+ibag;
                    Statement s=con.createStatement();
            s.execute("insert into plastic(PBottles,PBags,PContainers,PChairs)values('"+ibottle+"','"+ibags+"','"+icontainers+"','"+ichair+"')");
            out.print("Data inserted Successfully..!!");
            
        }
        catch(Exception e)
        {
            out.print(e);
        }
        finally {            
            out.close();
        }
    }

}
