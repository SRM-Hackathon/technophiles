package rubber ;/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "insertsr", urlPatterns = {"/insertsr"})
public class insertsr extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try  {   
            int ibo = 0;
            int icha = 0;
            int ico = 0;            int ibag = 0;            
                 int   ibottle =0;
                 int   ichair =0;
                 int   icontainers=0;
                 int   ibags=0;
                 
                 int ib =0;
           int iba = 0;
           int ic = 0;
           int ich = 0;
           Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/salecategory","root","");
                      Statement st = con.createStatement();

                       ResultSet rs=st.executeQuery("select * from rubber");
rs.next();
            String a=rs.getString("RTyres");
            String b=rs.getString("RRolls");
            String c=rs.getString("RDumbells");
            String d=rs.getString("RPipes");
            
            ib = Integer.parseInt(a);
            iba = Integer.parseInt(b);
            ic = Integer.parseInt(c);
            ich = Integer.parseInt(d);

            String bottles = request.getParameter("txttyre");
            String chairs = request.getParameter("txtroll");
            String containers = request.getParameter("txtdumbell");
            String bags = request.getParameter("txtpipe");
            
             ibo = Integer.parseInt(bottles);
             icha = Integer.parseInt(chairs);
             ico = Integer.parseInt(containers);
             ibag = Integer.parseInt(bags);
            
                    ibottle = ib+ibo;
                    ichair = iba+icha;
                    icontainers=ic+ico;
                    ibags=ich+ibag;
                    Statement s=con.createStatement();
            s.execute("insert into rubber(RTyres,RRolls,RDumbells,RPipes)values('"+ibottle+"','"+ichair+"','"+icontainers+"','"+ibags+"')");
            out.print("Data inserted Successfully..!!");
            
        }
        catch(Exception e)
        {
            out.print(e);
        }
        finally {            
            out.close();
        }
    }

    }

