-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2017 at 12:54 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.0.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `greenpeace`
--

-- --------------------------------------------------------

--
-- Table structure for table `hello`
--

CREATE TABLE `hello` (
  `user_FNAME` varchar(30) NOT NULL,
  `user_LNAME` varchar(30) NOT NULL,
  `user_Mail` varchar(30) NOT NULL,
  `user_Pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hello`
--

INSERT INTO `hello` (`user_FNAME`, `user_LNAME`, `user_Mail`, `user_Pass`) VALUES
('Ayushi', 'Raut', 'ayu123@gmail.com', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `plasticp`
--

CREATE TABLE `plasticp` (
  `id` int(11) NOT NULL,
  `PName` varchar(30) NOT NULL,
  `Amount` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plasticp`
--

INSERT INTO `plasticp` (`id`, `PName`, `Amount`, `Quantity`) VALUES
(1001, 'Bench', 510, 120),
(1002, 'Purse', 90, 150),
(1003, 'ClipBoards', 500, 150),
(1004, 'Bechiev Birds anf Feeder', 290, 150);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hello`
--
ALTER TABLE `hello`
  ADD PRIMARY KEY (`user_Mail`);

--
-- Indexes for table `plasticp`
--
ALTER TABLE `plasticp`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
