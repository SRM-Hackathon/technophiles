-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2017 at 04:59 AM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.0.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salecategory`
--

-- --------------------------------------------------------

--
-- Table structure for table `ewaste`
--

CREATE TABLE `ewaste` (
  `EComputers` int(11) NOT NULL,
  `EPhones` int(11) NOT NULL,
  `EBoards` int(11) NOT NULL,
  `EWires` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ewaste`
--

INSERT INTO `ewaste` (`EComputers`, `EPhones`, `EBoards`, `EWires`) VALUES
(0, 0, 0, 0),
(1, 2, 2, 2),
(1, 2, 3, 4),
(3, 4, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `glass`
--

CREATE TABLE `glass` (
  `GJars` int(11) NOT NULL,
  `GBottles` int(11) NOT NULL,
  `GMirrors` int(11) NOT NULL,
  `GEquipments` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `glass`
--

INSERT INTO `glass` (`GJars`, `GBottles`, `GMirrors`, `GEquipments`) VALUES
(0, 0, 0, 0),
(2, 1, 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `metal`
--

CREATE TABLE `metal` (
  `MBoxes` int(11) NOT NULL,
  `MPipes` int(11) NOT NULL,
  `MCans` int(11) NOT NULL,
  `MScraps` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `metal`
--

INSERT INTO `metal` (`MBoxes`, `MPipes`, `MCans`, `MScraps`) VALUES
(0, 0, 0, 0),
(1, 2, 3, 4),
(1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `paper`
--

CREATE TABLE `paper` (
  `PNews` int(11) NOT NULL,
  `PBoards` int(11) NOT NULL,
  `PBooks` int(11) NOT NULL,
  `PBags` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paper`
--

INSERT INTO `paper` (`PNews`, `PBoards`, `PBooks`, `PBags`) VALUES
(0, 0, 0, 0),
(1, 3, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `plastic`
--

CREATE TABLE `plastic` (
  `PBottles` int(11) NOT NULL,
  `PBags` int(11) NOT NULL,
  `PContainers` int(11) NOT NULL,
  `PChairs` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plastic`
--

INSERT INTO `plastic` (`PBottles`, `PBags`, `PContainers`, `PChairs`) VALUES
(0, 0, 0, 0),
(1, 3, 4, 2),
(6, 7, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `rubber`
--

CREATE TABLE `rubber` (
  `RTyres` int(11) NOT NULL,
  `RRolls` int(11) NOT NULL,
  `RDumbells` int(11) NOT NULL,
  `RPipes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rubber`
--

INSERT INTO `rubber` (`RTyres`, `RRolls`, `RDumbells`, `RPipes`) VALUES
(0, 0, 0, 0),
(1, 3, 5, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `plastic`
--
ALTER TABLE `plastic`
  ADD PRIMARY KEY (`PBottles`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
